#define VCS_REVISION "6457"
#define VCS_DATE "2014-10-26 23:49:15 +0200"
#define VCS_BRANCH "trunk"
